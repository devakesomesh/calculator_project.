from django.shortcuts import render, redirect
from .forms import CalcForm
from .models import Calculation
from django.contrib import messages
def index(request):
    form = CalcForm(request.POST or None)
    result = None
    expr = ''
    if request.method == 'POST' and form.is_valid():
        a = form.cleaned_data['a']
        b = form.cleaned_data['b']
        op = form.cleaned_data['op']
        try:
            if op == '+':
                r = a + b
            elif op == '-':
                r = a - b
            elif op == '*':
                r = a * b
            elif op == '/':
                r = a / b
            else:
                r = None
            result = r
            expr = f"{a} {op} {b}"
            # save to DB
            Calculation.objects.create(expression=expr, result=str(result))
        except Exception as e:
            messages.error(request, 'Error during calculation: ' + str(e))
    history = Calculation.objects.order_by('-created_at')[:20]
    return render(request, 'calculator/index.html', {'form':form,'result':result,'history':history})
