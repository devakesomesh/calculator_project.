from django import forms
class CalcForm(forms.Form):
    a = forms.FloatField(label='Operand A', required=True)
    b = forms.FloatField(label='Operand B', required=True)
    op = forms.ChoiceField(label='Operation', choices=[('+','Add'),('-','Subtract'),('*','Multiply'),('/','Divide')])
