Calculator (Django) — simple web calculator with history
-------------------------------------------------------
What you get:
- Django project `calculator_project`
- App `calculator`
- Simple calculator UI (add, subtract, multiply, divide)
- Calculation history saved to SQLite database (model: Calculation)
- HTML templates and CSS (static files)
- Admin configured so you can view history in Django admin
- Uploaded image included as static asset (logo)

Quick start (locally)
1. unzip the project and open folder in VS Code.
2. create & activate a virtual environment:
   python3 -m venv venv
   source venv/bin/activate   (Linux/macOS) or venv\Scripts\activate (Windows)
3. install requirements:
   pip install -r requirements.txt
4. apply migrations and create superuser:
   python manage.py migrate
   python manage.py createsuperuser
5. run server:
   python manage.py runserver
6. open http://127.0.0.1:8000/ in your browser.

Notes:
- The project uses SQLite by default (file: db.sqlite3).
- To use MySQL, update settings.py DATABASES and install mysqlclient.
